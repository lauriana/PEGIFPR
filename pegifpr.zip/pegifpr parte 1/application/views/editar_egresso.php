<?php $this->load->view('topo');?>
<html>
<head>

  <link rel="stylesheet" href="assets/css/main.css" />
</head>
<body>

  <section class="wrapper style2">
    <div class="container">
      <?php foreach ($egressos as $egresso) : ?>
          <form method="post" action="<?=base_url('atualizar')?>" enctype="multipart/form-data">
              <label for="nome_eg">Nome:</label>
                                        <input type="text" name="nome_eg" size="60" maxlength="60" id="nome_eg" disabled="" value="<?php echo $egresso->nome_eg?>"/>
                                    

                                                            
                                        <label for="n_curso">Curso</label>
                                        <input type="text" name="n_curso" size="100" maxlength="100" id="n_curso" disabled="" value="<?php echo $egresso->n_curso?>" />
                                                          
                                        <label for="ano_ing">Ano de ingresso:</label>
                                        <input type="text" name="endereco" size="4" maxlength="4" id="ano_ing" disabled="" value="<?php echo $egresso->ano_ing; ?>" />
                                                          
                                        <label for="ano_eg">Ano de egresso:</label>
                                        <input type="text" name="ano_eg" size="4" maxlength="4" id="ano_eg" disabled value="<?php echo $egresso->ano_eg; ?>" />
                                
                                                          
                                       
                                   
                                        <a href="<?php echo base_url('cadastroEgresso')?>" class="button">Cadastre-se</a>
                                        <input type="button" id="botaoCancelar" value="Cancelar" onclick="history.go(-1)" />
                                
                                </form>
              <?php endforeach; ?>
         
          </div>
          </section>
          </body>
          </html>

<?php $this->load->view('footer');?>