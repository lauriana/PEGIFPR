<?php $this->load->view('topo_admin');?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      //carrega o pacote dos gráficos  
      google.charts.load('current', {'packages':['corechart']});
    
      //define a função para criar o gráfico
      function drawChart() {
        <!-- as cores do gráfico serão geradas automaticamente-->
        var data = google.visualization.arrayToDataTable([
          ['Alunos', 'Quantidade'],
          ['2011',     135],
          ['2012',     74],
          ['2013',      69],
          ['2014',  94],
          ['2015', 73],
          ['2016', 81],
          ['2017', 89]
        ]);
        // criar a variavel options para definir as opções do gráfico
        var options = {
          title: 'Egressos por ano',
          is3D:true, // define que o gráfico em 3d estando setado como true
    
        };
        //aloca o tipo de gráfico na div GraficoColunas
var chart = new google.visualization.PieChart(document.getElementById('GraficoPizza'));
        chart.draw(data, options);
      }
    
      //carrega o grafico na página
      google.charts.setOnLoadCallback(drawChart);
    
    </script>
  </head>
  <body>
     <!-- conteiner para armazenar o gráfico de pizza-->
     <!-- a área de impressão do gráfico está definida no atributo style-->
    <div class="container" align="center" id="GraficoPizza" style="width: 900px; height: 500px;"></div>
     
    <input type="submit" class="button" id="botaoCancelar" value="Voltar" onclick="history.go(-1)" />

  </body>
</html>
<?php $this->load->view('footer');?>