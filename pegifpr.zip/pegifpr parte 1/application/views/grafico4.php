
<?php $this->load->view('topo_admin');?>
<html>
  <head>
  <link rel="stylesheet" href="assets/css/main.css" title="default" />
 <script src="https://www.gstatic.com/charts/loader.js" type="text/javascript"></script>
    <script type="text/javascript">
      //carrega o pacote dos gráficos   
      google.charts.load('current', {'packages':['corechart']});
     
      //define a função para criar o gráfico
      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Curso', 'Quantidade'],
          ['ADMINISTRAÇÃO',     56],
          ['ARTES VISUAIS',     28],
          ['CIÊNCIAS - HABILITAÇÃO: BIOLOGIA',      1],
          ['CIÊNCIAS BIOLÓGICAS',  24],
          ['CIÊNCIAS CONTÁBEIS', 81],
          ['CURSO SUPERIOR DE TECNOLOGIA AGROFLORESTAL', 1],
          ['DIREITO', 88],
          ['EDUCAÇÃO FÍSICA',     12],
          ['EDUCAÇÃO FÍSICA BACHARELADO',     40],
          ['EDUCAÇÃO FÍSICA - Licenciatura',      37],
          ['ENFERMAGEM',  37],
          ['ENGENHARIA AGRONÔMICA', 23],
          ['ENGENHARIA CIVIL', 48],
          ['FARMÁCIA', 89],
          ['LETRAS - Habilitação: Português-Inglês e respectivas Literaturas',     21],
          ['PEDAGOGIA - Licenciatura',     28],
          ['QUÍMICA',      41],
          ['RADIO E TV',  1],
          ['SISTEMAS DE INFORMAÇÃO', 12],
          ['TÉCNICO EM COOPERATIVISMO', 12],
          ['TÉCNICO EM VENDAS', 4]
        ]);
        // criar a variavel options para definir as opções do gráfico
        var options = {
          title: 'Egressos por cursos',
          
    
        };
        var chart = new google.visualization.ColumnChart(document.getElementById('GraficoColunas'));

        chart.draw(data, options);
      }
     
      //carrega o grafico na página
      google.charts.setOnLoadCallback(drawChart);
     
    </script>
  </head>
  <body>
    <!-- conteiner para armazenar o gráfico de colunas --> 
    <div id="GraficoColunas" class="container" style="height: 70em; width: 50em;">
    
</div>
<input type="submit" class="button" id="botaoCancelar" value="Voltar" onclick="history.go(-1)" />
</body>
</html>
<?php $this->load->view('footer');?>