<?php $this->load->view('topo');?>

<div class="wrapper style2">

  <article id="main" class="container special">
   

    <body>
     
     <script>
      function aumentaFonte() {
      //Pega o tamanho original da fonte
      tamanhoOriginal = document.getElementById('dep').style.fontSize;
      // da um split para separar o número da string 'em' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho

      novoTamanho = parseInt(vetor[0])+2;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('dep').style.fontSize = novoTamanho +'px';
      
    }
    function diminuiFonte() {
      //Pega o tamanho original da fonte neste caso 12px
      tamanhoOriginal = document.getElementById('dep').style.fontSize;
      // da um split para separar o número da string 'px' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho
      novoTamanho = parseInt(vetor[0])-2;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('dep').style.fontSize = novoTamanho +'px';
    }
  </script>

  
  <section class="depoimento">
   <div class="container" id="dep" style='font-size:17px'>
     
    
    <div class="ac_box">
      <div class="ac_box_top"><div>
       <div class="ac_box_cont">
        <h2>Depoimentos</h2>
        <?php foreach ($depoimentos as $depoimento) : ?>


         <br><br><p class="autor"><?php echo $depoimento->autor ?></p><br>
         <p align="justify"><?php echo $depoimento->descDep ?></p><br>
         <p align="right">Incluído em  <?php echo $depoimento->dataDep ?></p>
       <?php endforeach; ?>

     </div>
   </div>
 </div>
</div>
</div>
</section>
</body>
</article>
</div>
