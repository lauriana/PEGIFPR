<?php $this->load->view('topo');?>
<?php $this->load->view('header');?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />

</head>
<body>
<script>
    function aumentaFonte() {
      //Pega o tamanho original da fonte
      tamanhoOriginal = document.getElementById('home').style.fontSize;
      // da um split para separar o número da string 'em' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho

      novoTamanho = parseInt(vetor[0])+1;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('home').style.fontSize = novoTamanho +'px';
      
    }
    function diminuiFonte() {
      //Pega o tamanho original da fonte neste caso 12px
      tamanhoOriginal = document.getElementById('home').style.fontSize;
      // da um split para separar o número da string 'px' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho
      novoTamanho = parseInt(vetor[0])-1;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('home').style.fontSize = novoTamanho +'px';
    }
  </script>


	<!-- Highlights -->
	<section class="wrapper style2">
		<div class="container" id="home" style="font-size: 1em">

			
			<h1>Egressos do IFPR campus Palmas</h1>
			<p>Sejam bem-vindos ao Portal de Egressos do IFPR Campus Palmas (PEGIFPR). 
				<p>Ele foi desenvolvido com o objetivo de estabelecer um canal de comunicação com seus egressos, acompanhando seu desenvolvimento profissional e acadêmico, oportunizando a reestruturação curricular existente e para isso precisamos que informe alguns dados através de um cadastro. Caso seja de seu interesse compartilhar suas expreriências de forma pública dispomos de uma área para depoimentos. <p>
					Agradecemos desde já sua participação!</p>
				</div>
			</section>

		</div>
	</div>
</section>

			
	<!-- Scripts -->
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/jquery.dropotron.min.js"></script>
	<script src="assets/js/skel.min.js"></script>
	<script src="assets/js/util.js"></script>
	<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
	<script src="assets/js/main.js"></script>

</body>
</html>
<?php $this->load->view('footer');?>
