<?php $this->load->view('topo');?>
<html>
<head>

  <link rel="stylesheet" href="assets/css/main.css" />
</head>
<body>
  <script>
    function aumentaFonte() {
      //Pega o tamanho original da fonte
      tamanhoOriginal = document.getElementById('egressos').style.fontSize;
      // da um split para separar o número da string 'em' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho

      novoTamanho = parseInt(vetor[0])+2;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('egressos').style.fontSize = novoTamanho +'px';
      
    }
    function diminuiFonte() {
      //Pega o tamanho original da fonte neste caso 12px
      tamanhoOriginal = document.getElementById('egressos').style.fontSize;
      // da um split para separar o número da string 'px' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho
      novoTamanho = parseInt(vetor[0])-2;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('egressos').style.fontSize = novoTamanho +'px';
    }
  </script>
  <section class="wrapper style2">
    <div class="container" id="egressos" style="font-size: 17px">
      <form action="<?=base_url('pesquisarCpf')?>" enctype="multipart/form-data" method="post" >
        <label for="pesquisarCpf">CPF:</label>
        <input type="text" id="pesquisarCpf" name="pesquisarCpf" maxlength="11" required="" placeholder="Digite seu CPF sem traços ou pontos" /><!--Propriedade style="text-transform:uppercase"; deixa letra maiúscula-->


        <input type="submit" class="button" value="Enviar" btn-block/>
        <input type="submit" class="button" id="botaoCancelar" value="Voltar" onclick="history.go(-1)" />

      </form>
    </body>
    </html>





    <?php $this->load->view('footer');?>