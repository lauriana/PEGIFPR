 <form action="<?=base_url('pesquisarCurso')?>" enctype="multipart/form-data" method="post" >
        <label for="pesquisarCurso">Curso:</label>
        <input type="text" id="pesquisarCurso" name="pesquisarCurso" maxlength="60" style="text-transform: uppercase;";/><!--Propriedade style="text-transform:uppercase"; deixa letra maiúscula-->