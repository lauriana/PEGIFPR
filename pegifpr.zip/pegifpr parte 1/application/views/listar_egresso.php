<?php $this->load->view('topo');?>

<script>
  function aumentaFonte() {
      //Pega o tamanho original da fonte
      tamanhoOriginal = document.getElementById('egressos').style.fontSize;
      // da um split para separar o número da string 'em' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho

      novoTamanho = parseInt(vetor[0])+2;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('egressos').style.fontSize = novoTamanho +'px';
      
    }
    function diminuiFonte() {
      //Pega o tamanho original da fonte neste caso 12px
      tamanhoOriginal = document.getElementById('egressos').style.fontSize;
      // da um split para separar o número da string 'px' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho
      novoTamanho = parseInt(vetor[0])-2;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('egressos').style.fontSize = novoTamanho +'px';
    }
  </script>
  <section class="wrapper style2">
    <div class="container" id="egressos" style="font-size: 17px">
      <form action="<?=base_url('pesquisarNome')?>" enctype="multipart/form-data" method="post" >
        <label for="pesquisarNome">Nome:</label>
        <input type="text" id="pesquisarNome" name="pesquisarNome" maxlength="60" style="text-transform: uppercase;";/><!--Propriedade style="text-transform:uppercase"; deixa letra maiúscula-->

      <?php $this->load->view('busca_curso');?>
     


      <input type="submit" value="Pesquisar" btn-block/>
</form>
</form>
</div>
</section>
</div>
</section>
  
  <section class="wrapper style2">
    <div class="container" id="egressos">
      
      <table border="1">

        <thead>
          <tr>
            <th>Nome</th>
            <th>Curso</th>
            <th>Ano ingresso</th>
            <th>Ano egresso</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($egressos as $egresso) : ?>
            <tr>
              <td><?php echo $egresso->nome_eg ?></td>
              <td><?php echo $egresso->n_curso ?></td>
              <td><?php echo $egresso->ano_ing ?></td>
              <td><?php echo $egresso->ano_eg ?></td>

            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      
    </div>
  </section>
</div>
</section>



<?php $this->load->view('footer');?>