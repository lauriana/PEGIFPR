<?php $this->load->view('topo_admin');?>
<?php $this->load->view('header_admin');?>
<?php $this->load->view('footer');?>
