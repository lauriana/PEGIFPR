<div id="footer" style="font-size: 17px">
		

		<!-- Icons -->
		<ul class="icons">
			<li><a href="http://www.palmas.ifpr.edu.br" class="icon fa-icon"><img src="images/icon.png" width="25"><span class="label">IFPR</span></a></li>
			<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
			<li><a href="#" class="icon fa-linkedin"><span class="label">LinkedIn</span></a></li>
		</ul>

		<!-- Copyright -->
		<div class="copyright">
			<ul class="menu">
				<li>&copy; Patrícia Marques<br>Av. Bento Munhoz da Rocha Neto s/n. PRT-280. Trevo da Codapar - Palmas-PR <br> 
			</ul>
		</div>
	</div>

</body>
</html>