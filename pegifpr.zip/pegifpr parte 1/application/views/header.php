<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<!-- Banner -->
	
	<section id="banner" style="font-style: 1em">
		<header>
			<em><h2><b>Bem vindo Egresso!<br></em></h2><br><br>
			<a href="<?php echo base_url('controle_egresso')?>" class="button">Cadastre-se</a>
		</header>
	</section>
</body>
</html>