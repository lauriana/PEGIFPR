<?php $this->load->view('topo');?>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="<?= base_url("assets/css/main.css")?>">
<body>
  <section class="wrapper style2">
    <div class="container">
      <h2><?= $cabecalho ?></h2>
      <?php
            
        echo form_open('cadastroEgresso/atualizar/insere');
        echo form_hidden('ra', $registro->ra);
      
      ?>
      <label for="endereco">Endereço:</label>
      <input type="text" name="endereco" id="endereco" size="150" required="" maxlength="150"  value="<?= @$registro->endereco?>" />

      <br><label for="celular">Celular:</label>
      <input type="text" name="celular" id="celular" required="" size="14" maxlength="14"  value="<?= @$registro->celular?>" />


      <br><label for="email">E-mail:</label>
      <input type="text" name="email" id="email" size="60" required="" maxlength="60" value="<?= @$registro->email?>" />

      <br><label for="empresa">Empresa:</label>
      <input type="text" name="empresa" id="empresa"  required="" size="60" maxlength="60"  value="<?= @$registro->empresa?>" />

      <br><label for="profissao">Profissão:</label>
      <input type="text" name="profissao" id="profissao"  required="" size="60" maxlength="60"  value="<?= @$registro->profissao?>" />

      <br><label for="tempEmprego">Quanto tempo demorou para conseguir emprego na área?</label>
      <input type="text" name="tempEmprego" id="tempEmprego" required="" size="50" maxlength="30" placeholder="Não atuo na área/Durante a graduação/1 mês/1 ano/" value="<?= @$registro->tempEmprego?>" />

      <br><label for="comentario">Comente sobre o curso:</label>
      <br><textarea name="comentario" required="" placeholder="Comente o que não foi aprendido no curso e suas dificuldades ao ingressar no mercado de trabalho" id="comentario"><?= @$registro->comentario?></textarea>

      <p>
        <input type="submit" id="Enviar" value="Enviar" />
        <input type="button" id="botaoCancelar" value="Voltar" onclick="history.go(-1)" />
      </p>

      <?= form_close() ?>
    </body>
    </html>



  </div>
</section>
</body>
</html>

<?php $this->load->view('footer');?>