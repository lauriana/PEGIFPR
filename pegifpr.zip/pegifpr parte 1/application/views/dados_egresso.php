<?php $this->load->view('topo');?>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="assets/css/main.css" />
</head>

<body>

  <script>
    function aumentaFonte() {
      //Pega o tamanho original da fonte
      tamanhoOriginal = document.getElementById('egressos').style.fontSize;
      // da um split para separar o número da string 'em' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho

      novoTamanho = parseInt(vetor[0])+2;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('egressos').style.fontSize = novoTamanho +'px';
      
    }
    function diminuiFonte() {
      //Pega o tamanho original da fonte neste caso 12px
      tamanhoOriginal = document.getElementById('egressos').style.fontSize;
      // da um split para separar o número da string 'px' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho
      novoTamanho = parseInt(vetor[0])-2;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('egressos').style.fontSize = novoTamanho +'px';
    }
  </script>
  <div class="container" id="egressos" style="font-size: 14px">
    <p><?= @$this->session->flashdata('msg'); ?></p>


    <?php if ($egressos != false): ?>
      <?php foreach ($egressos as $egresso): ?>
        <h2 align="center">Dados do egresso</h2>
        <p><strong>Nome:</strong> <?= $egresso->nome_eg ?></p>

        <p><strong>Curso:</strong> <?php echo $egresso->n_curso?></p>
        <p>
          <strong>Ano de ingresso:</strong> <?= $egresso->ano_ing ?>  <strong>Ano de egresso:</strong> <?= $egresso->ano_eg ?>
        </p>
        
        <p>
          <strong>Endereço:</strong> <?= $egresso->endereco ?>
        </p>
        <p>
          <strong>Email:</strong> <?= $egresso->email ?>
        </p>
        <p>
          <strong>Celular:</strong> <?= $egresso->celular ?>
        </p>
        <p>
          <strong>Empresa:</strong> <?= $egresso->empresa ?>
        </p>
        <p>
          <strong>Profissão:</strong> <?= $egresso->profissao ?>
        </p>
        <p>
          <strong>Quanto tempo demorou para conseguir emprego na área?</strong> <?= $egresso->tempEmprego ?>
        </p>
        <p>
          <strong>Comente sobre o curso:</strong> <?= $egresso->comentario ?>
        </p>
        <p>
          <a title="alterar" class="button" href="<?php echo base_url() . 'cadastroEgresso/editar/' . $egresso->ra; ?>">Editar</a>
          <a title="alterar" class="button" href="<?php echo base_url('controle_egresso')?>">Voltar</a>
         <a href="<?php echo base_url('depoimento')?>" class="button">Adicionar depoimento</a>

        </p>
      <?php endforeach; ?>
    <?php else: ?>
      <p>Não há registros cadastrados!</p>
      <input type="button" id="botaoCancelar" value="Voltar" onclick="history.go(-1)" />
    <?php endif ?>
  </div>
</body>
</html>



<?php $this->load->view('footer');?>