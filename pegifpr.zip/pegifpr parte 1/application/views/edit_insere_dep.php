<?php $this->load->view('topo');?>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="<?= base_url("assets/css/main.css")?>">
  <body>
    <section class="wrapper style2">
      <div class="container">
        <h2><?= $cabecalho ?></h2>

        <p><?= validation_errors(); ?></p>

        <?php
        //verifica se o form vai ser usado para insert ou update
        if (!isset($registro->id_rio))
        {
            echo form_open('depoimento/insere');
        }
        else
        {
            echo form_open('depoimento/atualizar');

            echo form_hidden('id_dep', $registro->id_dep);
        }
        ?>
        <label for="endereco">Autor:</label>
        <input type="text" required="" name="autor" id="autor" size="60" required="" maxlength="60"  value="<?= @$registro->autor?>" />

        <br><label for="dataDep">Data:</label>
        <input type="date" name="dataDep" id="dataDep" disabled="" required="" value="<?php echo date('d/m/y');?>" />


        <br><label for="descDep">Descrição:</label>
      <br><textarea name="descDep" required="" placeholder="Comente sobre o curso" id="descDep"><?= @$registro->descDep?></textarea>

        
          <input type="submit" id="Enviar" value="Enviar" />
          <input type="button" id="botaoCancelar" value="Voltar" onclick="history.go(-1)" />
        </p>

        <?= form_close() ?>
      </body>
      </html>



    </div>
  </section>
</body>
</html>

<?php $this->load->view('footer');?>