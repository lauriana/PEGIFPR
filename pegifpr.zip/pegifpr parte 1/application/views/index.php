
<title>PEGIFPR</title>
<link rel="stylesheet" href="<?= base_url("assets/css/main.css")?>">
</head>
<body>
  <script>
    function aumentaFonte() {
      //Pega o tamanho original da fonte
      tamanhoOriginal = document.getElementById('home').style.fontSize;
      // da um split para separar o número da string 'em' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho

      novoTamanho = parseInt(vetor[0])+1;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('home').style.fontSize = novoTamanho +'px';
      
    }
    function diminuiFonte() {
      //Pega o tamanho original da fonte neste caso 12px
      tamanhoOriginal = document.getElementById('home').style.fontSize;
      // da um split para separar o número da string 'px' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho
      novoTamanho = parseInt(vetor[0])-1;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('home').style.fontSize = novoTamanho +'px';
    }
  </script>

  <section id="banner" >
    <div class="container" id="egressos" style="font-style: 1em">
      <?php if(!$this->session->userdata("usuario_logado")) : ?>
        <br><br><h1>Login</h1>
        <?php
        //Criação de formulario

        echo form_open("login/autenticar");

        echo form_label("E-mail", "email");
        echo form_input(array(
          "name" => "email",
          "id" => "email",
          "class" => "container",
          "naxlenth" => "255"
          ));
        echo form_label("Senha", "senha");
        echo form_password(array(
          "name" => "senha",
          "id" => "senha",
          "class" => "form-control",
          "naxlenth" => "255"
          )); 
        echo form_button(array(
          "class" => "button",
          "content" => "Logar",
          "type" => "submit"
          )); 


        echo form_close();
        ?>
      <?php endif?>
    </div>
  </body>
  </html>
 
