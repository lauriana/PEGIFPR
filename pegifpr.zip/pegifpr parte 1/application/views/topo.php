<!DOCTYPE HTML>
<html>
<head>
	<title>PEGIFPR</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href="assets/css/main.css" />
</head>
<body>
	<script>
		function aumentaFonte() {
      //Pega o tamanho original da fonte
      tamanhoOriginal = document.getElementById('header').style.fontSize;
      // da um split para separar o número da string 'em' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho

      novoTamanho = parseInt(vetor[0])+1;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('header').style.fontSize = novoTamanho +'px';
      
  }
  function diminuiFonte() {
      //Pega o tamanho original da fonte neste caso 12px
      tamanhoOriginal = document.getElementById('header').style.fontSize;
      // da um split para separar o número da string 'px' para aumentar o tamanho
      // irá gerar um vetor de 1 posição, a zero
      vetor = tamanhoOriginal.split('px');
      //pega o vetor 0 e acrescenta 5 para alterar o tamanho
      novoTamanho = parseInt(vetor[0])-1;
      //escreve novamente o style da div com o novo tamanho de fonte
      document.getElementById('header').style.fontSize = novoTamanho +'px';
  }


</script>
<div id="acessibilidade" align="right">
	<label>Acessibilidade: 
		<!--<a href="javascript:void(0);" Onclick="mudaFonte("mais"); return false">A
		<a href="javascript:mudaFonte('menos');">A-</a>
		<button value="A+" onclick='aumentaFonte()';</button>-->
			<button  onclick='aumentaFonte()'>A+</button>
			<button  onclick='diminuiFonte()'>A-</button>
			
		</label>
	</div>
	<div id="page-wrapper">
	</div>
	<!-- Header -->
	<div id="header" style="font-size: 17px" >

			<!-- Logo -->
						<h1><em><img src="images/g40.png" alt="" /></em></h1>

			<!-- Nav -->
			<nav id="nav">
				<ul>
					<li onclick=""><a href="<?php echo base_url('home')?>">Home</a>
						<li>
							<a href="<?php echo base_url('listar_depoimento')?>">Depoimentos</a>
						</li>
					
					<li>
						<a href="<?php echo base_url('egresso')?>">Egressos</a>
					</li>

					<li>
						<a href="<?php echo base_url('login')?>">Login</a>
					</li>
				
					</li>
				</ul>
			</nav>
		</div>
	</body>
	
	
	