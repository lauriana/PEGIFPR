<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Egresso_model extends CI_Model {

  var $table='egresso';
  function __construct() {
    parent::__construct();
    $this->load->helper('form','url');

  }

  public function get_egressos($sort = 'nome_eg', $order = 'asc'){
    $this->db->order_by($sort, $order);
    return $this->db->get('egresso')->result();
  }

  public function get_cad($sort = 'nome_eg', $order = 'asc'){
    $this->db->order_by($sort, $order);
    return $this->db->get('egresso')->result();
  }


  public function get_egressos_nome(){
    $this->load->helper('form','url');
    $termo = $this->input->post('pesquisarNome');
    $this->db->select('*');
    $this->db->like('LOWER(' .'nome_eg'. ')', strtolower($termo));
    return $this->db->get('egresso')->result();
  }

  public function get_egressos_curso(){

   $termo2 = $this->input->post('pesquisarCurso');
   $this->db->select('*');
   $this->db->like('LOWER(' .'n_curso'. ')',strtolower($termo2));
   return $this->db->get('egresso')->result();

 }


 public function get_egressos_cpf(){

   $termo3 = $this->input->post('pesquisarCpf');
   $this->db->select('*');
   $this->db->like('cpf',$termo3);
   return $this->db->get('egresso')->result();

 }
 public function get_egressos_cpf_dep(){

   $termo4 = $this->input->post('pesquisarCpf');
   $this->db->select('*');
   $this->db->like('cpf',$termo4);
   return $this->db->get('egresso')->result();

 }

 public function insert()
 {
  $data = $_POST;
  return $this->db->insert('egresso', $data);
}


public function get_where($ra)
{
  $this->db->where('ra', $ra);
  $query = $this->db->get('egresso');
  return $query->row();
}



public function update($ra)
{
  $data = $_POST;
  $this->db->where('ra', $ra);
  $this->db->update('egresso', $data);
}
}