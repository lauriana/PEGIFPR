<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
  
class Depoimento_model extends CI_Model {
 public $id_dep;
 public $autor;
 public $dataDep;
 public $descDep;

    function __construct() {
        parent::__construct();
        $this->load->helper('form','url');
        
    }

   
    /*function cadastrar($data) {
    return $this->db->insert('depoimentos', $data);
  }*/

  function listar() {
    $query = $this->db->get('depoimento');
    return $query->result();
}

  /*
  function deletar($id) {
    $this->db->where('id_dep', $id);
    return $this->db->delete('depoimentos');
}

  function editar($id) {
    $this->db->where('id_dep', $id);
    return $this->db->get('depoimentos')->result();
}
*/

public function get_cad($sort = 'dataDep', $order = 'asc'){
    $this->db->order_by($sort, $order);
    return $this->db->get('depoimento')->result();
  }
   public function insert()
 {
  $data = $_POST;
  return $this->db->insert('depoimento', $data);
}


public function get_where($id_dep)
{
  $this->db->where('id_dep', $id_dep);
  $query = $this->db->get('depoimento');
  return $query->row();
}



public function update($id_dep)
{
  $data = $_POST;
  $this->db->where('id_dep', $id_dep);
  $this->db->update('depoimento', $data);
}
}