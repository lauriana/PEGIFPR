<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Busca_rel extends CI_Controller{

    function __construct() {
        parent::__construct();
        $this->load->helper('form','url');
        $this->load->library('form_validation');
        $this->load->model('egresso_model');
    }


    public function index(){

            //Carrega o Model
        $this->load->model('egresso_model', '', TRUE);
        
            //Executa o método get_egressos
        $dados['egressos'] = $this->egresso_model->get_cad();
        
            //Carrega a View
        $this->load->view('busca', $dados);
    }

    public function pesquisarNome(){
            //Carrega o Model
        $this->load->model('egresso_model');
        
            
        $dados['egressos'] = $this->egresso_model->get_egressos_nome();
        
            //Carrega a View
        $this->load->view('listar_egresso', $dados);
    }

     
    public function pesquisarCurso(){
            //Carrega o Model
        $this->load->model('egresso_model');
        
            
        $dados['egressos'] = $this->egresso_model->get_egressos_curso();
        
            //Carrega a View
        $this->load->view('listar_egresso', $dados);
    }

    public function Salvar(){
        // Recupera os contatos através do model
       $this->load->model('egresso_model');
        // Passa os contatos para o array que será enviado à home
        //$dados['egressos'] =$this->egresso_model->formatar();
        // Executa o processo de validação do formulário
        $validacao = self::Validar();
        // Verifica o status da validação do formulário
        // Se não houverem erros, então insere no banco e informa ao usuário
        // caso contrário informa ao usuários os erros de validação
        if($validacao){
            // Recupera os dados do formulário
            $egresso = $this->input->post();
            // Insere os dados no banco recuperando o status dessa operação
            $status = $this->egresso_model->inserir($egresso);
            // Checa o status da operação gravando a mensagem na seção
            if(!$status){
                $this->session->set_flashdata('error', 'Não foi possível inserir o escolaridade.');
            }else{
                $this->session->set_flashdata('success', 'Escolaridade inserida com sucesso.');
                // Redireciona o usuário para a home
                redirect();
            }
        }else{
            $this->session->set_flashdata('error', validation_errors('<p>','</p>'));
        }
        // Carrega a home
        $this->load->view('edit_eg');
    }

        public function Editar(){
        // Recupera o ID do registro - através da URL - a ser editado
        $ra = $this->uri->segment(2);
        // Se não foi passado um ID, então redireciona para a home
        if(is_null($ra))
            redirect();
        // Recupera os dados do registro a ser editado
        $dados['egressos'] = $this->egresso_model->GetById($ra);
        // Carrega a view passando os dados do registro
        $this->load->view('edit_egresso',$dados);
    }
    /**
  * Processa o formulário para atualizar os dados
  */
    public function Atualizar(){
        // Realiza o processo de validação dos dados
        $validacao = self::Validar('update');
        // Verifica o status da validação do formulário
        // Se não houverem erros, então insere no banco e informa ao usuário
        // caso contrário informa ao usuários os erros de validação
        if($validacao){
            // Recupera os dados do formulário
            $egresso = $this->input->post();
            // Atualiza os dados no banco recuperando o status dessa operação
            $status = $this->egresso_model->Atualizar($egresso['ra'],$egresso);
            // Checa o status da operação gravando a mensagem na seção
            if(!$status){
                $dados['egresso'] = $this->egresso_model->GetById($egresso['ra']);
                $this->session->set_flashdata('error', 'Não foi possível atualizar o escolaridade.');
            }else{
                $this->session->set_flashdata('success', 'Escolaridades atualizado com sucesso.');
                // Redireciona o usuário para a home
                redirect();
            }
        }else{
            $this->session->set_flashdata('error', validation_errors());
        }
        // Carrega a view para edição
        $this->load->view('edit_eg');
    }

    private function Validar($operacao = 'insert'){
        // Com base no parâmetro passado
        // determina as regras de validação
        switch($operacao){
            
            
            case 'insert':
                $rules['nome_eg'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['cpf'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['n_curso'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['ano_ing'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['ano_eg'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['sexo'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['endereco'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['email'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['celular'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['empresa'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['profissao'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['comentario'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                break;

            case 'update':
                $rules['nome_eg'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['cpf'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['n_curso'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['ano_ing'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['ano_eg'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['sexo'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['endereco'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['email'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['celular'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['empresa'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['profissao'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['comentario'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                break;
            default:
                $rules['nome_eg'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['cpf'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['n_curso'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['ano_ing'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['ano_eg'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['sexo'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['endereco'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['email'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['celular'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['empresa'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['profissao'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                $rules['comentario'] = array('trim', 'required', 'min_length[4]','max_length[30]');
                break;
        }
        $this->form_validation->set_rules('nome_eg', 'nome_eg', $rules['nome_eg']);
        $this->form_validation->set_rules('cpf', 'cpf', $rules['cpf']);
        $this->form_validation->set_rules('n_curso', 'n_curso', $rules['n_curso']);
        $this->form_validation->set_rules('ano_ing', 'ano_ing', $rules['ano_ing']);
        $this->form_validation->set_rules('ano_eg', 'ano_eg', $rules['ano_eg']);
        $this->form_validation->set_rules('sexo', 'sexo', $rules['sexo']);
        $this->form_validation->set_rules('endereco', 'endereco', $rules['endereco']);
        $this->form_validation->set_rules('email', 'email', $rules['email']);
        $this->form_validation->set_rules('celular', 'celular', $rules['celular']);
        $this->form_validation->set_rules('empresa', 'empresa', $rules['empresa']);
        $this->form_validation->set_rules('profissao', 'profissao', $rules['profissao']);
        $this->form_validation->set_rules('comentario', 'comentario', $rules['comentario']);
        
        // Executa a validação e retorna o status
        return $this->form_validation->run();
    }
                
        
}