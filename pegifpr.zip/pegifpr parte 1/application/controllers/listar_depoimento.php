<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Listar_depoimento extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('form','url');
    }


    function index() {
        $data['titulo'] = "PEGIFPR";
        $this->load->model('depoimento_model');
        $data['depoimentos'] = $this->depoimento_model->listar();

        $this->load->view('listar_depoimentos', $data);
    }

    
    
}