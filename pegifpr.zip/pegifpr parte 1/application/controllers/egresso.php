<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Egresso extends CI_Controller{

    function __construct() {
        parent::__construct();
        $this->load->helper('form','url');
        $this->load->library('form_validation');
        //$this->load->model('egresso_model');
    }


    public function index(){

            //Carrega o Model
        $this->load->model('egresso_model', '', TRUE);
        
            //Executa o método get_egressos
        $dados['egressos'] = $this->egresso_model->get_egressos();
        
            //Carrega a View
        $this->load->view('listar_egresso', $dados);
    }

    public function pesquisarNome(){
            //Carrega o Model
        $this->load->model('egresso_model');
        
            
        $dados['egressos'] = $this->egresso_model->get_egressos_nome();
        
            //Carrega a View
        $this->load->view('listar_egresso', $dados);
    }

     
    public function pesquisarCurso(){
            //Carrega o Model
        $this->load->model('egresso_model');
        
            
        $dados['egressos'] = $this->egresso_model->get_egressos_curso();
        
            //Carrega a View
        $this->load->view('listar_egresso', $dados);
    }

   
                
        
}