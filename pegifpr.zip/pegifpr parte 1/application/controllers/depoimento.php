<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Depoimento extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('form','url');
        $this->load->library('form_validation');
        
    }

    public function index()
    {
        $data['titulo'] = "PEGIFPR";
        $data['cabecalho'] = "Depoimentos";
        $this->load->model('depoimento_model', '', TRUE);
        $data['depoimentos'] = $this->depoimento_model->get_cad();

        $this->load->view('edit_insere_dep', $data);
    }

    public function criar()
    {
        $data['titulo'] = "PEGIFPR - Editar depoimento";
        $data['cabecalho'] = "Criar novo depoimento";
        $this->load->view('edit_insere_dep', $data);
    }

    public function insere()
    {
        $this->load->model('depoimento_model', '', TRUE);
        $this->depoimento_model->insert();
        $this->session->set_flashdata('msg', 'Registro Criado com Sucesso!');
        redirect('listar_depoimento');
    }
    
    public function editar($id_dep)
    {
        $data['titulo'] = "PEGIFPR - Editar depoimento";
        $data['cabecalho'] = "Editar Depoimento";
        $this->load->model('depoimento_model', '', TRUE);
        $data['registro']=$this->depoimento_model->get_where($id_dep);

        $this->load->view('edit_insere_dep', $data);
    }

    public function atualizar()
    {
        $id_dep = $this->input->post('id_dep');
        $this->load->model('depoimento_model', '', TRUE);
        $data['registro']=$this->depoimento_model->update($id_dep);
        $this->session->set_flashdata('msg', 'Registro Atualizado com Sucesso!');
        redirect('listar_depoimento');
    }   
}