<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controle_acesso extends CI_Controller{

    function __construct() {
        parent::__construct();
        $this->load->helper('form','url');
        $this->load->library('form_validation');
        //$this->load->model('egresso_model');
    }


    public function index(){

            //Carrega o Model
        $this->load->model('usuario_model', '', TRUE);
        
            //Executa o método get_produtos
        $dados['usuarios'] = $this->usuario_model->get_usuarios();
        
            //Carrega a View
        $this->load->view('logar_user', $dados);
    }

    public function pesquisarCpfU(){
            //Carrega o Model
        $this->load->model('usuario_model');
        
            
        $dados['usuarios'] = $this->usuario_model-> get_usuarios_cpf();
        
            //Carrega a View
        $this->load->view('grafico', $dados);
    }

    public function pesquisarCurso(){
            //Carrega o Model
        $this->load->model('egresso_model');
        
            
        $dados['egressos'] = $this->egresso_model-> get_egressos_curso();
        
            //Carrega a View
        $this->load->view('grafico', $dados);
    }

     

    public function pesquisarTipo(){
            //Carrega o Model
        $this->load->model('usuario_model');
        
            
        $dados['usuarios'] = $this->usuario_model-> get_usuarios_tipo();
        
            //Carrega a View
        $this->load->view('home', $dados);
    }
}