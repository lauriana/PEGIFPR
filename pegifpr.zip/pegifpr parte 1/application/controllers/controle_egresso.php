<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Controle_egresso extends CI_Controller{

    function __construct() {
        parent::__construct();
        $this->load->helper('form','url');
        $this->load->library('form_validation');
        //$this->load->model('egresso_model');
    }


    public function index(){

            //Carrega o Model
        $this->load->model('egresso_model', '', TRUE);
        
            //Executa o método get_produtos
        $dados['egressos'] = $this->egresso_model->get_egressos();
        
            //Carrega a View
        $this->load->view('logar_egresso', $dados);
    }


    public function pesquisarCpf(){
            //Carrega o Model
        $this->load->model('egresso_model');
        
            
        $dados['egressos'] = $this->egresso_model-> get_egressos_cpf();
        
            //Carrega a View
        $this->load->view('dados_egresso', $dados);
    }
    
}