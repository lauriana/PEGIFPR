<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class cadastroEgresso extends CI_Controller{

    function __construct() {
        parent::__construct();
        $this->load->helper('form','url');
        $this->load->library('form_validation');
        //$this->load->model('egresso_model');
    }

    public function index()
    {
        $data['titulo'] = "SIRH";
        $data['cabecalho'] = "Egressos";
        $this->load->model('egresso_model', '', TRUE);
        $data['egressos'] = $this->egresso_model->get_cad();

        $this->load->view('cad_egresso', $data);
    }

    public function criar()
    {
        $data['titulo'] = "PEGIFPR - Editar egresso";
        $data['cabecalho'] = "Criar novo Egresso";
        $this->load->view('edit_eg', $data);
    }

    public function insere()
    {
        $this->load->model('egresso_model', '', TRUE);
        $this->egresso_model->insert();
        $this->session->set_flashdata('msg', 'Registro Criado com Sucesso!');
        redirect('controle_egresso');
    }
    
    public function editar($ra)
    {
        $data['titulo'] = "PEGIFPR - Editar egresso";
        $data['cabecalho'] = "Editar Egresso";
        $this->load->model('egresso_model', '', TRUE);
        $data['registro']=$this->egresso_model->get_where($ra);

        $this->load->view('edit_eg', $data);
    }

    public function atualizar()
    {
        $ra = $this->input->post('ra');
        $this->load->model('egresso_model', '', TRUE);
        $data['registro']=$this->egresso_model->update($ra);
        $this->session->set_flashdata('msg', 'Registro Atualizado com Sucesso!');
        redirect('controle_egresso');
    }       
}